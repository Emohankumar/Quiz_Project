from django.urls import path

from . import views

urlpatterns = [
    path('', views.user_login, name='login'),
    path('register/', views.user_registration, name='register'),
    path('logout/', views.user_logout, name='logout'),
    path('quiz/', views.quiz_list, name='quiz_list'),
    path('<int:quiz_id>/', views.quiz, name='quiz'),
    path('question_sub/<int:question_id>/', views.question_submission, name='quiz'),
    path('question/<int:question_id>/', views.question, name='question'),
]