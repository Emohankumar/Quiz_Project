from django.shortcuts import render, HttpResponseRedirect, redirect
from django.contrib.auth import authenticate, login, logout
from .models import MyUser, Question, Quiz, QuizSubmission
from .models import Quiz, QuizSubmission, Question
from django.contrib.auth.decorators import login_required


def user_login(request):
    """
    Function for user login
    :param request:
    :return:
    """

    if request.method == "POST":

        email = request.POST["email"]
        password = request.POST["password"]
        user = authenticate(username=email, password=password)
        if user is not None:
            login(request, user)
            return HttpResponseRedirect("/quiz/quiz/")
        return render(request, "competition/login.html", {"error": "Invalid user"})
    return render(request, "competition/login.html")


def user_registration(request):
    """
    Function for user register
    :param request:
    :return:
    """
    if request.method == "POST":
        username = request.POST['username']
        email = request.POST["email"]
        password = request.POST['password']
        if username.strip() and email.strip() and password.strip():
            MyUser.objects.create_user(email=email.strip(), password=password.strip(), username=username.strip())
            return render(request, "competition/login.html")
        else:
            return render(request, "competition/register.html", {"error": "Please submit all the data"})
    return render(request, "competition/register.html")


@login_required(login_url="/quiz/")
def user_logout(request):
    """
    Function for user logout
    :param request:
    :return:
    """
    logout(request)
    return redirect("/quiz/")


@login_required(login_url="/quiz/")
def quiz_list(request):
    """
    Showing all the quiz
    :param request:
    :return:
    """
    quiz = Quiz.objects.all()
    return render(request, "competition/selectquiz.html", {"quiz": quiz})


@login_required(login_url="/quiz/")
def quiz(request, quiz_id):
    """
    Function for showing the questions for a quiz
    :param request:
    :return:
    """
    quiz = Quiz.objects.get(pk=quiz_id)
    return render(request, "competition/quiz.html", {"quiz": quiz})


@login_required(login_url="/quiz/")
def question(request, question_id):
    """
    Function for going to Question Details.
    :param request:
    :param question_id:
    :return:
    """
    question = Question.objects.get(pk=question_id)
    return render(request, "competition/question.html", {"question": question})


@login_required(login_url="/quiz/")
def question_submission(request, question_id):
    """
    Function for Submitting the question.
    :param request:
    :param question_id:
    :return:
    """
    question = Question.objects.get(id=question_id)
    if not request.POST.get("choice"):
        return render(request, "competition/question.html", {"question": question, "error": "Please select a choice"})
    point = 0
    answer = question.answer
    if answer == request.POST['choice']:
        point = 1
    QuizSubmission.objects.create(user=request.user, question_id=question_id, answer=request.POST["choice"],
                                  point=point)
    return render(request, "competition/quiz.html", {"quiz": question.quiz, "message": "Question Submitted Successfully"})
