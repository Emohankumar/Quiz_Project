from django.forms import ModelForm
from .models import MyUserManager


class StudentEnrollementForm(ModelForm):
    class Meta:

        model = MyUserManager
        fields = ["username", "email_id", "password"]

