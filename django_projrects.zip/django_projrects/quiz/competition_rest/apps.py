from django.apps import AppConfig


class CompetitionRestConfig(AppConfig):
    name = 'competition_rest'
