from django.shortcuts import render
from django.db.models import F
from rest_framework.views import APIView
from rest_framework.response import Response
from competition.models import QuizSubmission


class UserInfo(APIView):

    def get(self, request, user_id):
        """
        User Response
        :param request:
        :param user_id:
        :return:
        """
        return Response(list(
            QuizSubmission.objects.filter(user_id=user_id).annotate(ques_text=F("question__question_text"),
                                                                    correct_answer=F("question__answer"),
                                                                    given_answer=F("answer")).values(
                "ques_text", "correct_answer", "given_answer")))
